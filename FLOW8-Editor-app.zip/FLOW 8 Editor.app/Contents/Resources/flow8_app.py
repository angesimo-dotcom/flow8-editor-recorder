#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FLOW 8 Editor — app standalone per Behringer FLOW 8

  • controllo del mixer via MIDI su USB (CoreMIDI, tramite python-rtmidi)
  • registrazione multitraccia a 10 canali (CoreAudio, tramite sounddevice)
  • interfaccia: flow8-editor.html in una finestra propria (pywebview)

Avvio:
  python3 flow8_app.py             finestra dell'app
  python3 flow8_app.py --browser   apre l'interfaccia nel browser predefinito
  python3 flow8_app.py --demo      senza mixer: audio e MIDI simulati
"""
import argparse
import datetime
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
UI_FILE = os.path.join(HERE, 'flow8-editor.html')
SETTINGS_FILE = os.path.join(os.path.expanduser('~'), '.flow8-editor.json')
DEFAULT_DIR = os.path.join(os.path.expanduser('~'), 'Music', 'FLOW8 Registrazioni')
SR = 48000
WB = SR // 50                       # una colonna della forma d'onda = 20 ms

MISSING = []
try:
    import sounddevice as sd
except Exception as e:              # PortAudio mancante o pacchetto non installato
    sd = None
    MISSING.append(f'sounddevice ({e})')
try:
    import soundfile as sf
except Exception as e:
    sf = None
    MISSING.append(f'soundfile ({e})')
try:
    import rtmidi
except Exception as e:
    rtmidi = None
    MISSING.append(f'python-rtmidi ({e})')


def safe_name(t):
    t = re.sub(r'[\\/:*?"<>|]+', '-', str(t)).strip()
    return re.sub(r'\s+', '_', t) or 'traccia'


# ============================================================ MIDI
class MidiEngine:
    def __init__(self, demo):
        self.demo = demo
        self.out = None
        self.name = None
        self.lock = threading.Lock()
        self.sent = 0

    def ports(self):
        if self.demo:
            return ['FLOW 8 (demo)']
        if not rtmidi:
            return []
        m = rtmidi.MidiOut()
        try:
            return list(m.get_ports())
        finally:
            del m

    def open(self, name):
        with self.lock:
            if self.out is not None and not self.demo:
                try:
                    self.out.close_port()
                except Exception:
                    pass
            self.out, self.name = None, None
            if not name:
                return
            if self.demo:
                self.out, self.name = 'demo', name
                return
            if not rtmidi:
                raise RuntimeError('python-rtmidi non è installato')
            m = rtmidi.MidiOut()
            ports = list(m.get_ports())
            if name not in ports:
                raise RuntimeError(f'Porta MIDI «{name}» non trovata. Premi «Aggiorna».')
            m.open_port(ports.index(name))
            self.out, self.name = m, name

    def send(self, msgs):
        with self.lock:
            if self.out is None:
                raise RuntimeError('Nessuna uscita MIDI aperta')
            many = len(msgs) > 8
            for m in msgs:
                b = [int(x) & 0xFF for x in m]
                if not self.demo:
                    self.out.send_message(b)
                self.sent += 1
                if many:
                    time.sleep(0.001)   # non intasare il mixer con «Invia tutto»


# ============================================================ AUDIO
class AudioEngine:
    def __init__(self, demo):
        self.demo = demo
        self.ctrl = threading.Lock()        # start/stop
        self.lock = threading.Lock()        # dati condivisi con la callback
        self.stream = None
        self.nch = 0
        self.name = ''
        self.peaks = np.zeros(0, np.float32)
        self.xruns = 0
        # registrazione
        self.rec = False
        self.q = None
        self.writer = None
        self.files, self.specs, self.paths = [], [], []
        self.dir = None
        self.frames = 0
        self.err = None
        self.take = 0
        self.rec_chs = []
        self.wmin, self.wmax = [], []
        self._demo_run = False

    # ---------------------------------------------------- dispositivi
    def devices(self, rescan=False):
        if self.demo:
            return [{'id': 0, 'name': 'FLOW 8 (demo)', 'ch': 10}]
        if not sd:
            return []
        if rescan and self.stream is None:
            try:                            # PortAudio legge i dispositivi solo all'avvio
                sd._terminate()
                sd._initialize()
            except Exception:
                pass
        out = []
        for i, d in enumerate(sd.query_devices()):
            if d['max_input_channels'] > 0:
                out.append({'id': i, 'name': d['name'], 'ch': int(d['max_input_channels'])})
        return out

    # ---------------------------------------------------- stream
    def start(self, dev_id):
        with self.ctrl:
            if self.rec:
                raise RuntimeError('Registrazione in corso')
            self._stop_stream()
            self.xruns = 0
            if self.demo:
                self.nch, self.name = 10, 'FLOW 8 (demo)'
                self.peaks = np.zeros(10, np.float32)
                self._demo_run = True
                threading.Thread(target=self._demo_loop, daemon=True).start()
                return self.info()
            if not sd:
                raise RuntimeError('sounddevice non è installato')
            info = sd.query_devices(dev_id, 'input') if dev_id is not None else sd.query_devices(kind='input')
            n = int(info['max_input_channels'])
            if n < 1:
                raise RuntimeError('Il dispositivo non ha ingressi')
            dev = dev_id                    # None = ingresso predefinito
            try:
                st = sd.InputStream(device=dev, channels=n, samplerate=SR, dtype='float32',
                                    latency='high', callback=self._cb)
                st.start()
            except Exception as e:
                raise RuntimeError(f'Impossibile aprire «{info["name"]}» a {n} canali / {SR} Hz: {e}')
            self.stream, self.nch, self.name = st, n, info['name']
            self.peaks = np.zeros(n, np.float32)
            return self.info()

    def info(self):
        return {'name': self.name, 'channels': self.nch, 'samplerate': SR} if self.nch else None

    def _stop_stream(self):
        self._demo_run = False
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
        self.stream, self.nch, self.name = None, 0, ''

    def stop(self):
        self.stop_rec()
        with self.ctrl:
            self._stop_stream()

    def _cb(self, indata, frames, t, status):
        if status:
            self.xruns += 1
        pk = np.max(np.abs(indata), axis=0)
        with self.lock:
            if self.peaks.shape == pk.shape:
                np.maximum(self.peaks, pk, out=self.peaks)
        if self.rec:
            self.q.put(indata.copy())

    def _demo_loop(self):
        """Segnale finto a 10 canali, in tempo reale, per provare l'app senza mixer."""
        rng = np.random.default_rng(7)
        freqs = [110, 220, 330, 440, 82, 123, 196, 262, 150, 151]
        t0, n, B = time.perf_counter(), 0, 480
        while self._demo_run:
            dt = t0 + n / SR - time.perf_counter()
            if dt > 0:
                time.sleep(dt)
            t = (n + np.arange(B)) / SR
            blk = np.empty((B, 10), np.float32)
            for c in range(10):
                env = 0.5 + 0.5 * np.sin(2 * np.pi * (0.13 + 0.05 * c) * t + c)
                hit = (np.sin(2 * np.pi * (1.0 + 0.25 * c) * t + c) > 0.85).astype(np.float32)
                blk[:, c] = 0.4 * env * np.sin(2 * np.pi * freqs[c] * t) + 0.3 * hit * rng.standard_normal(B)
            self._cb(blk, B, None, None)
            n += B

    # ---------------------------------------------------- registrazione
    def start_rec(self, tracks, fmt, folder, prefix):
        with self.ctrl:
            if not sf:
                raise RuntimeError('soundfile non è installato')
            if not self.nch:
                raise RuntimeError('Audio non attivo')
            if self.rec:
                raise RuntimeError('Già in registrazione')
            folder = os.path.expanduser(folder or DEFAULT_DIR)
            session = f'{safe_name(prefix or "Sessione")}_{datetime.datetime.now():%Y%m%d_%H%M%S}'
            d = os.path.join(folder, session)
            os.makedirs(d, exist_ok=True)
            subtype = 'FLOAT' if fmt == 'f32' else 'PCM_24'
            files, specs, used = [], [], set()
            try:
                for t in tracks:
                    chs = [int(c) for c in t.get('chs', []) if 0 <= int(c) < self.nch]
                    if not chs:
                        continue
                    base = f'{session}_{safe_name(t.get("name", "traccia"))}'
                    nm, k = base, 2
                    while nm in used:
                        nm, k = f'{base}_{k}', k + 1
                    used.add(nm)
                    files.append(sf.SoundFile(os.path.join(d, nm + '.wav'), 'w', SR, len(chs),
                                              subtype=subtype, format='WAV'))
                    specs.append(chs)
            except Exception:
                for f in files:
                    f.close()
                raise
            if not files:
                raise RuntimeError('Nessuna traccia valida da registrare')
            self.files, self.specs = files, specs
            self.paths = [f.name for f in files]
            self.dir, self.frames, self.err = d, 0, None
            self.rec_chs = sorted({c for s in specs for c in s})
            with self.lock:
                self.wmin, self.wmax = [], []
                self.take += 1
            self.q = queue.Queue()
            self.writer = threading.Thread(target=self._write_loop, daemon=True)
            self.writer.start()
            self.rec = True
            return {'dir': d, 'files': [os.path.basename(p) for p in self.paths], 'take': self.take}

    def _write_loop(self):
        n = self.nch
        pend = np.zeros((0, n), np.float32)
        failed = False
        while True:
            blk = self.q.get()
            if blk is None:
                break
            if not failed:
                try:
                    for f, chs in zip(self.files, self.specs):
                        f.write(blk[:, chs])
                except Exception as e:
                    self.err = f'Errore di scrittura: {e}'
                    failed = True
            self.frames += len(blk)
            pend = np.concatenate((pend, blk))
            k = len(pend) // WB
            if k:
                seg = pend[:k * WB].reshape(k, WB, n)
                mn = np.clip(np.round(seg.min(axis=1) * 127), -127, 127).astype(np.int8)
                mx = np.clip(np.round(seg.max(axis=1) * 127), -127, 127).astype(np.int8)
                with self.lock:
                    self.wmin.extend(mn)
                    self.wmax.extend(mx)
                pend = pend[k * WB:]
        for f in self.files:
            try:
                f.close()
            except Exception as e:
                self.err = self.err or f'Errore in chiusura file: {e}'

    def stop_rec(self):
        with self.ctrl:
            if not self.writer:
                return None
            self.rec = False
            time.sleep(0.05)                # lascia arrivare l'ultimo blocco
            self.q.put(None)
            self.writer.join(timeout=60)
            self.writer = None
            return {'dir': self.dir, 'files': [os.path.basename(p) for p in self.paths],
                    'seconds': round(self.frames / SR, 2), 'error': self.err}

    def poll(self, since):
        with self.lock:
            pk = self.peaks.tolist()
            self.peaks[:] = 0
            total = len(self.wmin)
            since = max(0, min(int(since), total))
            end = min(total, since + 3000)
            mn = [a.tolist() for a in self.wmin[since:end]]
            mx = [a.tolist() for a in self.wmax[since:end]]
            take = self.take
        return {
            'peaks': pk, 'recording': self.rec, 'elapsed': self.frames / SR,
            'xruns': self.xruns, 'error': self.err, 'take': take, 'rec_chs': self.rec_chs,
            'backlog': self.q.qsize() if (self.q and self.rec) else 0,
            'audio': self.info(),
            'wave': {'start': since, 'n': end - since, 'min': mn, 'max': mx, 'total': total},
        }


# ============================================================ HTTP
MIDI = AUDIO = None
DEMO = False
WINDOW = None


def load_settings():
    try:
        with open(SETTINGS_FILE, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def pick_folder(current):
    if WINDOW is not None:
        import webview
        ftype = getattr(webview, 'FileDialog', None)
        kind = ftype.FOLDER if ftype else webview.FOLDER_DIALOG
        res = WINDOW.create_file_dialog(kind, directory=current or '')
        return res[0] if res else None
    if sys.platform == 'darwin':
        r = subprocess.run(['osascript', '-e', 'POSIX path of (choose folder with prompt "Cartella per le registrazioni")'],
                           capture_output=True, text=True)
        return r.stdout.strip() or None
    raise RuntimeError('Scrivi il percorso della cartella nel campo')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode('utf-8'), 'application/json; charset=utf-8')

    def do_GET(self):
        u = urlparse(self.path)
        qs = parse_qs(u.query)
        try:
            if u.path in ('/', '/index.html'):
                with open(UI_FILE, 'rb') as f:
                    self._send(200, f.read(), 'text/html; charset=utf-8')
            elif u.path == '/api/devices':
                self._json({'midi': MIDI.ports(), 'audio': AUDIO.devices(rescan='rescan' in qs),
                            'midiOpen': MIDI.name, 'audioOpen': AUDIO.info(), 'demo': DEMO,
                            'missing': MISSING, 'defaultDir': DEFAULT_DIR})
            elif u.path == '/api/poll':
                self._json(AUDIO.poll(qs.get('since', ['0'])[0]))
            elif u.path == '/api/settings':
                self._json(load_settings())
            else:
                self._json({'error': 'not found'}, 404)
        except Exception as e:
            self._json({'error': str(e)}, 500)

    def do_POST(self):
        u = urlparse(self.path)
        try:
            n = int(self.headers.get('Content-Length') or 0)
            body = json.loads(self.rfile.read(n) or b'{}') if n else {}
            p = u.path
            if p == '/api/midi/open':
                MIDI.open(body.get('name'))
                self._json({'ok': True, 'name': MIDI.name})
            elif p == '/api/midi/send':
                MIDI.send(body.get('msgs', []))
                self._json({'ok': True})
            elif p == '/api/audio/start':
                self._json(AUDIO.start(body.get('id')))
            elif p == '/api/audio/stop':
                AUDIO.stop()
                self._json({'ok': True})
            elif p == '/api/rec/start':
                self._json(AUDIO.start_rec(body.get('tracks', []), body.get('fmt', 'pcm24'),
                                           body.get('folder'), body.get('prefix')))
            elif p == '/api/rec/stop':
                self._json(AUDIO.stop_rec() or {'files': []})
            elif p == '/api/settings':
                with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
                    json.dump(body, f, ensure_ascii=False, indent=1)
                self._json({'ok': True})
            elif p == '/api/pickfolder':
                self._json({'folder': pick_folder(body.get('current'))})
            elif p == '/api/reveal':
                path = body.get('path') or ''
                if sys.platform == 'darwin' and os.path.exists(path):
                    subprocess.Popen(['open', path])
                self._json({'ok': True})
            else:
                self._json({'error': 'not found'}, 404)
        except Exception as e:
            self._json({'error': str(e)}, 400)


def make_server(port):
    for p in [port] + list(range(port + 1, port + 20)) + [0]:
        try:
            return ThreadingHTTPServer(('127.0.0.1', p), Handler)
        except OSError:
            continue
    raise RuntimeError('Nessuna porta libera')


def main():
    global MIDI, AUDIO, DEMO, WINDOW
    ap = argparse.ArgumentParser(description='FLOW 8 Editor')
    ap.add_argument('--demo', action='store_true', help='audio e MIDI simulati, senza mixer')
    ap.add_argument('--browser', action='store_true', help='usa il browser invece della finestra dell\'app')
    ap.add_argument('--port', type=int, default=8765)
    ap.add_argument('--app', action='store_true', help=argparse.SUPPRESS)
    a = ap.parse_args()

    DEMO = a.demo
    MIDI, AUDIO = MidiEngine(DEMO), AudioEngine(DEMO)
    srv = make_server(a.port)
    url = f'http://127.0.0.1:{srv.server_address[1]}/'
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    print('FLOW 8 Editor —', url, '(demo)' if DEMO else '')
    for m in MISSING:
        print('  ! modulo non disponibile:', m)

    try:
        use_window = not a.browser
        if use_window:
            try:
                import webview
            except Exception as e:
                print('  ! pywebview non disponibile:', e)
                if a.app:                   # avviato come app: niente Terminale, quindi avvisa ed esci
                    subprocess.run(['osascript', '-e', 'display dialog "Impossibile aprire la finestra dell\'app (pywebview). Dettagli in Libreria/Logs/FLOW8 Editor.log" with title "FLOW 8 Editor" buttons {"OK"}'])
                    return
                use_window = False
        if use_window:
            WINDOW = webview.create_window('FLOW 8 Editor', url, width=1560, height=980, min_size=(1000, 700))
            webview.start()
        else:
            webbrowser.open(url)
            print('Premi Ctrl+C per uscire.')
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        res = AUDIO.stop_rec()
        if res:
            print('Registrazione chiusa:', res)
        AUDIO.stop()
        srv.shutdown()


if __name__ == '__main__':
    main()
